# PROMPT CLAUDE CODE — KIRIMKU (UI/UX FULL APP)

Bertindak sebagai **Senior Product Designer, Senior Android Engineer, dan UX Engineer**. Bangun aplikasi **KirimKu**, aplikasi Indonesia untuk **pesan makanan + ojek online**, dengan kualitas visual premium, konsisten, interaktif, dan siap dikembangkan lebih lanjut.

## 1. WAJIB BACA REFERENSI VISUAL

Buka dan periksa gambar berikut sebelum coding:

`design-reference/kirimku-full-uiux-reference.png`

Gambar tersebut adalah **referensi arah desain dan peta layar**, bukan screenshot yang harus ditiru mentah-mentah. Ambil struktur informasi, hierarki, nuansa warna hijau, kualitas mockup, dan cakupan flow. Buat UI final yang lebih rapi, realistis, konsisten, dan mudah digunakan.

Jangan mengabaikan referensi. Jangan menghasilkan satu halaman saja lalu menyebutnya full app.

## 2. PRODUK DAN TARGET

Nama: **KirimKu**

Tagline: **Makan enak • Antar cepat • Sampai tujuan**

Pasar awal: pengguna Indonesia. Bahasa UI: Indonesia. Mata uang: Rupiah (Rp). Gunakan contoh nama, alamat, restoran, makanan, dan nomor kendaraan yang masuk akal sebagai data DEMO; jangan mengklaim data atau layanan itu nyata.

Dua layanan inti:
1. **Pesan makanan** dari restoran.
2. **Ojek online** untuk perjalanan dari titik jemput ke tujuan.

Untuk tahap ini fokus pada **UI/UX prototype yang berjalan dan interaktif**, bukan mengklaim layanan produksi telah tersedia. Peta, GPS, pembayaran, driver, chat, promo, dan status real-time boleh memakai data simulasi dengan penandaan yang sesuai.

## 3. MULAI DARI REPO YANG ADA

Sebelum mengubah apa pun:
1. Periksa struktur repository, README, package/build files, dependency, dan kode yang sudah ada.
2. Identifikasi stack yang digunakan saat ini.
3. Pertahankan stack dan pola proyek yang sudah sehat; jangan menghapus atau mengganti konfigurasi penting tanpa alasan.
4. Jika repository kosong, gunakan **Android native Kotlin + Jetpack Compose + Material 3** sebagai pilihan default.
5. Jika repository sudah menggunakan stack lain, lanjutkan stack yang ada dan implementasikan desain yang sesuai.
6. Jangan berhenti hanya untuk bertanya. Ambil keputusan teknis yang wajar, dokumentasikan asumsi, lalu kerjakan.

Jika native Android:
- Gunakan Kotlin, Jetpack Compose, Material 3, Navigation Compose, dan ViewModel/state yang sesuai.
- Pisahkan UI, model, data demo, navigasi, dan komponen reusable.
- Utamakan kompatibilitas dengan konfigurasi Gradle yang ada.
- Jangan menambahkan dependency hanya untuk efek kosmetik yang bisa dibuat sederhana tanpa dependency.

## 4. ART DIRECTION / DESIGN SYSTEM

Buat tampilan **modern, premium, hangat, bersih, dan khas produk lokal**, bukan template generik.

Warna awal:
- Primary green: `#087F4F`
- Deep green: `#064E3B`
- Light green surface: `#E8F5ED`
- Background: `#F7F8F5`
- Main text: `#202923`
- Secondary text: `#68736D`
- Border: `#E4E9E4`
- Error: merah yang tetap terbaca dan tidak mendominasi.

Ketentuan visual:
- Gunakan sistem spacing yang konsisten (kelipatan 4/8 dp).
- Sudut kartu dan tombol konsisten; jangan semua elemen diberi radius berlebihan.
- Tipografi punya hierarki jelas: heading, body, label, caption.
- Ikon harus konsisten. Gunakan ikon vektor yang cocok; hindari emoji sebagai pengganti ikon UI.
- Gunakan foto makanan yang menggugah selera dan visual yang konsisten. Jika aset gambar eksternal tidak tersedia, buat placeholder lokal yang rapi dan jangan membuat UI rusak.
- Hindari gradient berlebihan, glassmorphism acak, bayangan berat, layout padat, dan dekorasi yang tidak membantu.
- Jangan menaruh semua informasi pada satu layar.
- Gunakan bottom navigation yang konsisten dan nyaman untuk ibu jari.
- Pastikan status bar, system navigation, safe areas, keyboard, dan scroll tidak menutupi konten.
- Responsif pada ukuran layar Android yang umum.
- Semua teks UI menggunakan bahasa Indonesia yang natural.
- Jangan membuat klaim promo, harga diskon, ETA, atau keamanan seolah fakta nyata. Semua data contoh harus jelas sebagai demo bila diperlukan.

## 5. INFORMASI ARSITEKTUR / NAVIGASI UTAMA

Bottom navigation:
1. **Beranda**
2. **Aktivitas**
3. **Bantuan** (atau Pesan jika lebih masuk akal untuk struktur yang ada)
4. **Akun**

Pada Beranda tampilkan:
- Sapaan singkat.
- Pemilih alamat/lokasi tujuan.
- Search bar: “Cari makanan atau restoran”.
- Dua service card utama: **Makanan** dan **Ojek**.
- Kategori makanan.
- Banner promo demo yang tidak menutupi konten.
- Restoran pilihan/populer.
- Item menu dengan foto, nama, harga demo, rating demo, dan estimasi demo.
- Akses cepat ke aktivitas dan bantuan.

## 6. DAFTAR LAYAR YANG HARUS DIIMPLEMENTASIKAN

Buat navigasi nyata di antara layar-layar berikut. Untuk flow yang membutuhkan banyak layar, boleh memakai state/sheet/dialog dengan desain konsisten, tetapi setiap aksi utama harus bekerja.

### A. Onboarding dan akun
- Splash screen dengan identitas KirimKu.
- Onboarding 2–3 halaman atau alur pengenalan ringkas.
- Login/daftar sebagai prototype.
- Form nomor telepon dan input OTP demo, tanpa mengirim SMS sungguhan.
- State validasi input, loading, dan error.
- Pengguna boleh masuk ke mode demo agar alur dapat diuji tanpa backend.

### B. Beranda
- Pemilihan alamat.
- Pencarian makanan/restoran.
- Kategori.
- Banner promo demo.
- Daftar restoran dan rekomendasi.
- Tombol layanan Makanan dan Ojek.

### C. Pemesanan makanan
- Daftar restoran dengan pencarian dan filter sederhana.
- Detail restoran: nama, rating demo, kategori, estimasi demo, status buka demo.
- Daftar menu dengan gambar, harga, deskripsi, opsi variasi bila relevan.
- Detail item/menu: kuantitas, catatan, opsi tambahan jika ada.
- Keranjang: tambah/kurangi jumlah, hapus item, catatan pesanan.
- Ringkasan biaya dengan subtotal, biaya antar demo, diskon demo opsional, dan total.
- Pilih alamat pengantaran.
- Pilih metode pembayaran DEMO.
- Konfirmasi pesanan.
- Status pesanan dengan tahapan: pesanan diterima → disiapkan → kurir menuju restoran → dalam perjalanan → selesai.
- Detail pesanan dan tombol bantuan.
- Batalkan pesanan dengan konfirmasi, jika status demo memungkinkan.

### D. Ojek online
- Form lokasi jemput dan tujuan.
- Pilih lokasi lewat input dan daftar lokasi demo, tanpa mengklaim GPS sungguhan bila belum diintegrasikan.
- Tampilan map-like yang rapi. Jika belum ada map SDK/API key, gunakan peta placeholder/ilustrasi lokal dan tandai sebagai simulasi; jangan menampilkan peta palsu sebagai GPS real-time.
- Pilihan layanan motor.
- Estimasi tarif demo dan ringkasan rute.
- Konfirmasi pesanan.
- State mencari driver dengan animasi halus dan tombol batal.
- Driver ditemukan: avatar/initial, nama demo, kendaraan dan plat demo, rating demo, tombol telepon/chat simulasi.
- Tracking perjalanan demo dengan status dan estimasi demo.
- Perjalanan selesai dan ringkasan.

### E. Aktivitas
- Tab/segmen pesanan makanan dan perjalanan.
- Riwayat demo.
- Detail transaksi/pesanan.
- Status yang mudah dipahami.
- Pesan ulang dari pesanan selesai, bila sesuai.

### F. Chat dan bantuan
- Chat simulasi dengan driver/kurir, input pesan dan pesan dummy.
- Tombol kirim benar-benar menambahkan pesan ke UI.
- Pusat bantuan berisi kategori pertanyaan dan kontak simulasi.
- Jangan mengaku bisa menelepon atau mengirim pesan ke pihak nyata.

### G. Akun
- Profil pengguna demo.
- Edit profil lokal.
- Daftar alamat tersimpan, tambah/edit/hapus.
- Metode pembayaran demo.
- Voucher demo.
- Pengaturan notifikasi lokal/demo.
- Pusat bantuan.
- Tentang KirimKu.
- Keluar akun dengan konfirmasi.

### H. UI states dan edge cases
Buat desain untuk:
- Loading/skeleton.
- Empty state.
- Pencarian tidak menemukan hasil.
- Validasi form.
- Kesalahan simulasi.
- Pesanan dibatalkan.
- Keranjang kosong.
- Tidak ada koneksi (simulasi).
- Konfirmasi sebelum tindakan destruktif.
- Toast/snackbar untuk aksi berhasil/gagal.

## 7. INTERAKSI WAJIB BERFUNGSI

Jangan membuat tombol dekoratif yang tidak melakukan apa-apa. Minimal:
- Semua bottom navigation bekerja.
- Kategori dan kartu layanan membuka halaman yang benar.
- Search bar menerima input dan memfilter data demo.
- Kartu restoran membuka detail restoran.
- Item menu membuka detail atau dapat langsung ditambahkan sesuai desain.
- Tambah/kurangi item mengubah kuantitas dan total.
- Keranjang tetap konsisten saat berpindah layar.
- Pemilihan alamat dan metode pembayaran mengubah pilihan aktif.
- Form tidak dapat dikonfirmasi dengan input wajib yang kosong.
- Konfirmasi pembayaran/pesanan mengubah status ke state berikutnya.
- Alur ojek bergerak dari isi lokasi → tarif → konfirmasi → mencari driver → driver ditemukan → perjalanan → selesai.
- Chat dapat mengirim pesan simulasi.
- Edit profil/alamat menyimpan perubahan dalam state lokal.
- Tombol kembali bekerja sesuai ekspektasi Android.
- Loading, error, empty state, dan konfirmasi ditangani dengan baik.

Gunakan state management yang sesuai stack. Untuk prototype tanpa backend, simpan state penting lokal dengan solusi ringan yang sesuai proyek; jangan menambahkan backend palsu atau meminta API key yang belum tersedia.

## 8. KUALITAS KODE DAN STRUKTUR

- Buat komponen reusable: AppButton, ServiceCard, RestaurantCard, FoodItemCard, PriceRow, AddressSelector, StatusTimeline, EmptyState, LoadingState, dan komponen lain sesuai kebutuhan.
- Pisahkan data demo dari komponen UI.
- Hindari satu file raksasa.
- Hindari duplikasi layout dan hard-coded styling yang tidak konsisten.
- Gunakan nama variabel/komponen yang jelas.
- Jangan meninggalkan TODO untuk fungsi inti yang diminta.
- Jangan menghapus fitur repo lama yang tidak terkait.
- Jika aset eksternal tidak tersedia, gunakan placeholder yang pantas dan dokumentasikan cara mengganti aset.
- Jangan menyertakan secret, token, API key, atau kredensial.

## 9. PROSES KERJA — JANGAN BERHENTI DI RENCANA

Kerjakan dalam urutan berikut:
1. Audit repository dan referensi gambar.
2. Tentukan struktur dan design system.
3. Implementasikan komponen bersama dan navigasi.
4. Implementasikan flow makanan sampai konfirmasi dan tracking.
5. Implementasikan flow ojek sampai perjalanan selesai.
6. Implementasikan aktivitas, chat/bantuan, akun, dan edge states.
7. Jalankan formatter/linter/test/build yang tersedia.
8. Perbaiki error yang ditemukan; jangan hanya melaporkannya.
9. Periksa ulang seluruh flow dan konsistensi visual.
10. Buat dokumentasi cara menjalankan aplikasi dan daftar fitur yang masih berupa simulasi.

Jangan berhenti setelah membuat wireframe, mockup statis, landing page, atau daftar rencana. **Implementasikan aplikasi yang benar-benar dapat dijalankan di repository ini.**

## 10. SELF-CHECK WAJIB SEBELUM SELESAI

Bandingkan hasil implementasi dengan `design-reference/kirimku-full-uiux-reference.png`, lalu cek:

- [ ] Identitas KirimKu konsisten di seluruh layar.
- [ ] Hijau, tipografi, spacing, radius, dan ikon konsisten.
- [ ] Beranda menonjolkan dua layanan: makanan dan ojek.
- [ ] Foto makanan, harga, nama, dan informasi item tersusun rapi.
- [ ] Flow makanan lengkap sampai status pesanan.
- [ ] Flow ojek lengkap sampai perjalanan selesai.
- [ ] Semua tombol utama benar-benar berfungsi.
- [ ] Navigasi kembali dan bottom navigation berfungsi.
- [ ] Tidak ada layar kosong yang tidak disengaja.
- [ ] Tidak ada teks terpotong, overflow, elemen bertumpuk, atau tombol tertutup keyboard.
- [ ] Loading, error, empty, dan confirmation state tersedia.
- [ ] UI tetap nyaman pada layar Android kecil dan besar.
- [ ] Build/test yang tersedia sudah dijalankan dan hasilnya dilaporkan jujur.

Jika menemukan masalah, perbaiki dahulu sebelum menyatakan selesai.

## 11. LAPORAN AKHIR

Setelah implementasi, laporkan secara ringkas:
1. Fitur dan layar yang sudah selesai.
2. Cara menjalankan/build aplikasi dengan perintah yang sesuai repository.
3. Hasil build/test (berhasil atau gagal; jangan mengarang).
4. Fitur yang masih simulasi dan integrasi yang dibutuhkan untuk produksi.
5. Lokasi file penting serta cara mengganti aset visual.

Mulai sekarang: audit repository, buka gambar referensi, lalu implementasikan.
